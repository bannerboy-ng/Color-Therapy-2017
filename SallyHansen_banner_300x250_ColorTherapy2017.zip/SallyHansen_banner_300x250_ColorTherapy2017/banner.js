var bannerboy = bannerboy || {};
bannerboy.main = function() {

	var width = 300;
	var height = 250;
	var banner = bannerboy.createElement({perspective: 1000, id: "banner", width: width, height: height, backgroundColor: "#ffffff", overflow: "hidden", cursor: "pointer", parent: document.body});

	// adform vars
	var clickTAGvalue = dhtml.getVar('clickTAG', 'http://www.example.com');
	var landingpagetarget = dhtml.getVar('landingPageTarget', '_blank');

	var images = [
	"frame_2.jpg", 
	"frame_1.jpg", 
	"pack.png", 
	"cta_txt.png", 
	"cta_txt_hover.png", 
	"txt_1.png", 
	"logo.png", 
	];

	bannerboy.preloadImages(images, function() {

		/* Create elements
		================================================= */
		/* eslint-disable indent, no-unused-vars */
		
		var bottom_plate = bannerboy.createElement({backgroundColor: "#d3b1a9", width: 300, height: 250, parent: banner});
		var top_plate = bannerboy.createElement({backgroundColor: "#671733", width: 300, height: 75, parent: banner});
		var frame_container = bannerboy.createElement({left: 8, width: 282, height: 182, parent: banner});
			var frame_2 = bannerboy.createElement({backgroundImage: "frame_2.jpg", retina: true, parent: frame_container});
			var frame_1 = bannerboy.createElement({backgroundImage: "frame_1.jpg", retina: true, parent: frame_container});
		var pack = bannerboy.createElement({backgroundImage: "pack.png", left: 216, top: 93, retina: true, parent: banner});
		var cta = bannerboy.createElement({left: 8, top: 221, width: 145, height: 21, parent: banner});
			var cta_base = bannerboy.createElement({backgroundColor: "#671733", width: 145, height: 21, parent: cta});
			var cta_txt = bannerboy.createElement({backgroundImage: "cta_txt.png", left: 7, top: 6, retina: true, parent: cta});
			var cta_hover = bannerboy.createElement({width: 145, height: 21, parent: cta});
				var cta_base_hover = bannerboy.createElement({backgroundColor: "#ffffff", width: 145, height: 21, parent: cta_hover});
				var cta_txt_hover = bannerboy.createElement({backgroundImage: "cta_txt_hover.png", left: 7, top: 6, retina: true, parent: cta_hover});
		var txt_1 = bannerboy.createElement({backgroundImage: "txt_1.png", left: 8, top: 108, retina: true, parent: banner});
		var logo = bannerboy.createElement({backgroundImage: "logo.png", left: 173, top: 14, retina: true, parent: banner});

		var border = bannerboy.createElement({width: width, height: height, border: "1px solid #000", boxSizing: "border-box", parent: banner});
		
		/* eslint-enable indent, no-unused-vars */

		/* Adjustments
		================================================= */

		cta_hover.set({opacity: 0}); 

		/* Initiate
		================================================= */

		/* Animations
		================================================= */

		frame_container.tl_in = new BBTimeline()

		.fromTo(frame_1, 0.01, {opacity: 0}, {opacity: 1, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 1}, {opacity: 0, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 0}, {opacity: 1, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 1}, {opacity: 0, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 0}, {opacity: 1, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 1}, {opacity: 0, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 0}, {opacity: 1, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 1}, {opacity: 0, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 0}, {opacity: 1, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 1}, {opacity: 0, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 0}, {opacity: 1, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 1}, {opacity: 0, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 0}, {opacity: 1, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 1}, {opacity: 0, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 0}, {opacity: 1, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 1}, {opacity: 0, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 0}, {opacity: 1, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 1}, {opacity: 0, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 0}, {opacity: 1, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 1}, {opacity: 0, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 0}, {opacity: 1, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 1}, {opacity: 0, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 0}, {opacity: 1, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 1}, {opacity: 0, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 0}, {opacity: 1, ease: Linear.easeNone})
		.chain(0.5)
		.fromTo(frame_1, 0.01, {opacity: 1}, {opacity: 0, ease: Linear.easeNone})

		/* Main Timeline
		================================================= */

		main_tl = new BBTimeline()

		.add(frame_container.tl_in)

		scrubber(main_tl);

		/* Interactions
		================================================= */
		banner.addEventListener("mouseenter", function() {
				cta_hover.to(0.0001, {opacity: 1})
		});

		banner.addEventListener("mouseleave", function() {
				cta_hover.to(0.0001, {opacity: 0})				
		});

		banner.onclick = function() {
		    window.open(clickTAGvalue, landingpagetarget); 
		}

	    /* Helper
		================================================= */

		/* Scrubber
		================================================= */
		function scrubber(tl) {
			if (window.location.origin == "file://") {
				bannerboy.include(["../bannerboy_scrubber.min.js"], function() {
					if (bannerboy.scrubberController) bannerboy.scrubberController.create({"main timeline": tl});
				});
			}
		}
	});
};